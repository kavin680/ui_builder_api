export class FreezeConfiguration {}
